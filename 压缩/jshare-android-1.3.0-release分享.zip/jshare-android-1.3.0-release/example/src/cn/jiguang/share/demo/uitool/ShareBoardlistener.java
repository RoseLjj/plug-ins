package cn.jiguang.share.demo.uitool;

/**
 * Created by cloud on 17/1/13.
 */

public interface ShareBoardlistener {
    void onclick(SnsPlatform var1, String var2);
}
