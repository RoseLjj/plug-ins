### JMessage WEB SDK v2.3.1

#### 更新时间

+ 2017-08-11

#### Change Log

##### NewFeature:
+ 事件同步
+ 自定义通知栏
+ 消息转发
+ 群屏蔽列表

#### 升级提示

+ 建议升级！

#### 升级指南

+ 用最新的 jmessage-sdk-web.2.3.1.min.js 替换掉老版本的 sdk


