//
//  ViewController.h
//  DemoInPutPasswordView
//
//  Created by lqcjdx on 15/6/9.
//  Copyright (c) 2015年 YL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UILabel *resultLabel;

- (IBAction)showInputView:(UIButton *)sender;

@end

